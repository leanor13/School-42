<div align="center">
  
![42-Exam](https://github.com/user-attachments/assets/61713aed-c895-4804-9023-8ae8be8003d9)

</div>
